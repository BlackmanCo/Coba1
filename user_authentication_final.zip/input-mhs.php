<?php 
	include "koneksi.php";

	$idmhs			= $_POST['idmhs'];
	$npm			= $_POST['npm'];
	$nama			= $_POST['nama'];
	$idprodi		= $_POST['idprodi'];

	$input = "INSERT INTO mahasiswa VALUES('$idmhs', '$npm', '$nama','$idprodi')";
	mysqli_query($koneksi,$input);
	echo "<script>window.alert('Berhasil Ditambahkan'); window.location.href='mhs.php'</script>";
 ?>