<?php 
	include "koneksi.php";

	$delete = "DELETE FROM mahasiswa WHERE idmhs='$_GET[id]'";
	mysqli_query($koneksi,$delete);
	echo"<script>window.alert('Berhasil Dihapus'); window.location.href='mhs.php#content'</script>";
 ?>