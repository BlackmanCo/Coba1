<?php 
	include "koneksi.php";

	$npm		= $_POST['npm'];
	$nama		= $_POST['nama'];
	$idprodi	= $_POST['idprodi'];

	$update = "UPDATE mahasiswa SET npm='$npm', nama='$nama',idprodi='$idprodi' WHERE idmhs='$_GET[id]' ";
	mysqli_query($koneksi,$update);
	echo "<script>window.alert('Berhasil Diubah'); window.location.href='mhs.php#content'</script>";
 ?>