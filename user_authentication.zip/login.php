<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>USER AUTHENTICATION</title>
</head>
<body>
	<h2>Login User</h2>
	<form action="sistem.php?op=in" method="post">
		Username : <input type="text" name="usr">
		<br>
		<br>
		Password : <input type="password" name="psw">
		<br>
		<br>
		<input type="submit" value="Login">
	</form>
</body>
</html>